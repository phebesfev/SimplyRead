document.addEventListener("DOMContentLoaded", () => {
    console.log("Popup loaded.");
  });